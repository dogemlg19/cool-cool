function onCreate()
	makeLuaSprite('bg', 'galaxycollapse', 0, 0);
	setObjectCamera('bg', 'camhud');
	setProperty('bg.alpha', 0.5);
	addLuaSprite('bg', true);
end
function onCreatePost()
	setProperty('dad.visible', false);
	setProperty('gf.visible', false);
	setProperty('boyfriend.visible', false);
	setProperty('iconP2.visible', false);
	setProperty('iconP1.visible', false);
	--[[if downscroll then
		setProperty('scoreTxt.y', getProperty('scoreTxt.y') - 109);
		setProperty('healthBarBG.y', getProperty('healthBarBG.y') - 70);
		setProperty('healthBar.y', getProperty('healthBar.y') - 70);
	else
		setProperty('scoreTxt.y', getProperty('scoreTxt.y') + 10);
		setProperty('healthBarBG.y', getProperty('healthBarBG.y') + 50);
		setProperty('healthBar.y', getProperty('healthBar.y') + 50);
	end]]--

	setProperty('scoreTxt.y', 678);
	if downscroll then
		setProperty('timeBar.y', 11);
		setProperty('timeTxt.y', 0);
	end
	triggerEvent('Camera Follow Pos', 750, 350)
	forceMiddlescroll()
end
function onCountdownTick(tick)
	if tick == 0 then
		updateLaneUnderlay()
		setProperty('laneunderlayOpponent.visible', false)
	end
end

function onUpdate()
	setProperty('healthBar.angle', 90)
	setProperty('healthBar.x', getProperty('laneunderlay.x') + 202)
	setProperty('healthBar.y', 413)
end
function noteMiss()
	setProperty('health', getProperty('health') - 0.02) -- loss 0.06475 hp
end
function goodNoteHit()
	setProperty('health', getProperty('health') - 0.015) -- gain 0.008 hp >:)
end

function forceMiddlescroll() -- working with more than 4 keys!
	for i = 0, getProperty('opponentStrums.length') do
		setPropertyFromGroup('opponentStrums', i, 'visible', false);
	end
	if not middlescroll then
		for i = 0, getProperty('playerStrums.length') do
			setPropertyFromGroup('playerStrums', i, 'x', getPropertyFromGroup('playerStrums', i, 'x') - 320);
		end
	end
end