function onCreatePost()
	makeLuaSprite("sky", "cozmik/sky", -480, -330)
	scaleObject("sky", 1.4, 1.4)
	setScrollFactor("sky", 0.05, 0.05)
	addLuaSprite("sky", false)
	
	makeLuaSprite("bridge", "cozmik/bridge", -70, 120)
	scaleObject("bridge", 1.2, 1.2)
	setScrollFactor("bridge", 0.1, 0.1)
	addLuaSprite("bridge", false)
	
	makeLuaSprite("road", "cozmik/road", -340, 500)
	setScrollFactor("road", 0.4, 0.4)
	addLuaSprite("road", false)
	
	makeLuaSprite("warehouse", "cozmik/warehouse", -1200, -300)
	scaleObject("warehouse", 1.3, 1.3)
	setScrollFactor("warehouse", 0.95, 0.95)
	addLuaSprite("warehouse", false)
	
	if not lowQuality then
		makeLuaSprite("pallets_left", "cozmik/pallets", -1030, 950)
		scaleObject("pallets_left", 1.6, 1.6)
		setScrollFactor("pallets_left", 1.2, 1.2)
		addLuaSprite("pallets_left", true)
		
		makeLuaSprite("pallets_right", "cozmik/pallets", 1350, 750)
		scaleObject("pallets_right", 1.1, 1.1)
		setProperty("pallets_right.flipX", true)
		addLuaSprite("pallets_right", false)
		
		makeLuaSprite("overlay", "cozmik/overlay", -900, -100)
		setBlendMode("overlay", "add")
		setProperty("overlay.alpha", 0.3)
		addLuaSprite("overlay", true)
	end
end

-- crash prevention
function onUpdate() end
function onUpdatePost() end
